package com.example.josephlaycano.smartparkingmonitor;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private DatabaseValues mockValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DatabaseValues mockValues = new DatabaseValues();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView spotTakenA = (TextView) findViewById(R.id.spotTakenA);
        TextView spotTakenB = (TextView) findViewById(R.id.spotTakenB);
        TextView spotTakenC = (TextView) findViewById(R.id.spotTakenC);

        TextView overlimitA = (TextView) findViewById(R.id.overlimitA);
        TextView overlimitB = (TextView) findViewById(R.id.overlimitB);
        TextView overlimitC = (TextView) findViewById(R.id.overlimitC);

        TextView timeA = (TextView) findViewById(R.id.timeA);
        TextView timeB = (TextView) findViewById(R.id.timeB);
        TextView timeC = (TextView) findViewById(R.id.timeC);

        Button simulateButton = (Button) findViewById(R.id.simulateButton);
        simulateButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

            }
        });

        for(int i = 0; i < 3; i++) {
            mockValues.setSpotTaken(false, i);
            mockValues.setTimer(i, 0);
        }

        spotTakenA.setText("Spot Taken: " + mockValues.getSpot(0));
        spotTakenB.setText("Spot Taken: " + mockValues.getSpot(1));
        spotTakenC.setText("Spot Taken: " + mockValues.getSpot(2));

        overlimitA.setText("Over Limit: " + mockValues.isOverlimit(0));
        overlimitB.setText("Over Limit: " + mockValues.isOverlimit(1));
        overlimitC.setText("Over Limit: " + mockValues.isOverlimit(2));

        timeA.setText("Time Parked: " + mockValues.getTime(0));
        timeB.setText("Time Parked: " + mockValues.getTime(1));
        timeC.setText("Time Parked: " + mockValues.getTime(2));
    }
}
