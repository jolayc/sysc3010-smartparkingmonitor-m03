package com.example.josephlaycano.smartparkingmonitor;

/**
 * Created by josephlaycano on 12/3/2017.
 */

public class DatabaseValues {
    private boolean[] spotTaken;
    private int[] elapsedTimes;

    public DatabaseValues() {
        spotTaken = new boolean[3];
        elapsedTimes = new int[3];
    }

    public void setSpotTaken(boolean status, int ID) {
        spotTaken[ID] = status;
    }

    public void setTimer(int ID, int time) {
        elapsedTimes[ID] = time;
    }

    public boolean isOverlimit(int ID) {
        if(elapsedTimes[ID] > 90) {
            return true;
        }
        return false;
    }

    public boolean getSpot(int ID) {
        return spotTaken[ID];
    }

    public int getTime(int ID) {
        return elapsedTimes[ID];
    }

}
